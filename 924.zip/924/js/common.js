document.addEventListener('touchstart', function () { });

